var textarea, button;

function setup() {
  noCanvas();

  textarea = select("textarea");
  button = select("button")
  button.mousePressed(buttonClicked);
}

function buttonClicked() {
  nlu(textarea.value(), nluComplete);
}

function nluComplete(response) {
  // Print complete response
  print(response);

  // ==== SENTIMENT ANALYSIS ====
  createElement("h2", "Sentiment analysis");
  var sentiment = response.result.sentiment.document;
  print(sentiment);
  createSpan("Positiveness: ");
  var positiveness = createElement("progress");
  positiveness.value(map(sentiment.score, -1, 1, 0, 1));
  createSpan(round(sentiment.score * 100) + "%");

  if (sentiment.label == "positive")
    createSpan("😊");
  else if (sentiment.label == "neutral")
    createSpan("😐");
  else
    createSpan("🙁");


  // ==== CATEGORIES ANALYSIS ====
  var categories = response.result.categories;
  print(categories);
  createElement("h2", "Categories");

  createP("This speech is about: <b>" + categories[0].label + "</b>");
  

  createP("This speech is about: <b>" + categories[1].label + "</b>");


  createP("This speech is about: <b>" + categories[2].label + "</b>");
  // ==== EMOTION ANALYSIS ====
if (response.result.emotion) { // only with English texts
    createElement("h2", "Emotion analysis");
    var emotion = response.result.emotion.document.emotion;
  
    createSpan("Joy");
    var progressJoy = createElement("progress");
    progressJoy.value(emotion.joy);
    createSpan(round(emotion.joy * 100) + "%");
    createElement("br");
  
    createSpan("Sadness");
    var progressSadness = createElement("progress");
    progressSadness.value(emotion.sadness);
    createSpan(round(emotion.sadness * 100) + "%");
    createElement("br");

  createSpan("Fear");
    var progressFear = createElement("progress");
    progressFear.value(emotion.fear);
    createSpan(round(emotion.fear * 100) + "%");
    createElement("br");
  
   createSpan("Disgust");
    var progressDisgust = createElement("progress");
    progressDisgust.value(emotion.disgust);
    createSpan(round(emotion.disgust * 100) + "%");
    createElement("br");
  
    createSpan("Anger");
    var progressAnger = createElement("progress");
    progressAnger.value(emotion.anger);
    createSpan(round(emotion.anger * 100) + "%");
  
    // ==== USAGE ANALYSIS ====

   var usage = response.result.usage;
  print(usage);
  createElement("h2", "Usage");
    createP("The number of characters in the text : <b>" + usage.text_characters + "</b>");
  
  
  // ==== CONCEPTS ANALYSIS ====
  var concepts = response.result.concepts;
  print(concepts);
  createElement("h2", "Concepts Analysis");
  
  createP("The concept number 1: <b>" + concepts[0].text + "</b>");
  createP("The concept number 2: <b>" + concepts[1].text + "</b>");
  createP("The concept number 3: <b>" + concepts[2].text + "</b>");
  createP("The concept number 4: <b>" + concepts[3].text + "</b>");
  createP("The concept number 5: <b>" + concepts[4].text + "</b>");
  createP("The concept number 6: <b>" + concepts[5].text + "</b>");
  createP("The concept number 7: <b>" + concepts[6].text + "</b>");
  createP("The concept number 8: <b>" + concepts[7].text + "</b>");

  // ==== Entities ANALYSIS ====
    
  var entities = response.result.entities;
  print(entities);
  createElement("h2", "Entities Analysis");
  
  createP("The name: <b>" + entities[0].text + "</b>");
  createP("The type: <b>" + entities[0].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[0].count + "</b>");
  
  createP("The name: <b>" + entities[1].text + "</b>");
  createP("The type: <b>" + entities[1].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[1].count + "</b>");
  
  createP("The name: <b>" + entities[2].text + "</b>");
  createP("The type: <b>" + entities[2].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[2].count + "</b>");
  createP("The name: <b>" + entities[3].text + "</b>");
  createP("The type: <b>" + entities[3].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[3].count + "</b>");
  
  createP("The name: <b>" + entities[4].text + "</b>");
  createP("The type: <b>" + entities[4].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[4].count + "</b>");
  
  createP("The name: <b>" + entities[5].text + "</b>");
  createP("The type: <b>" + entities[5].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[5].count + "</b>");
  
  createP("The name: <b>" + entities[6].text + "</b>");
  createP("The type: <b>" + entities[6].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[6].count + "</b>");
  
  createP("The name: <b>" + entities[7].text + "</b>");
  createP("The type: <b>" + entities[7].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[7].count + "</b>");
  
  createP("The name: <b>" + entities[8].text + "</b>");
  createP("The type: <b>" + entities[8].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[8].count + "</b>");
  
  createP("The name: <b>" + entities[9].text + "</b>");
  createP("The type: <b>" + entities[9].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[9].count + "</b>");
  
  createP("The name: <b>" + entities[10].text + "</b>");
  createP("The type: <b>" + entities[10].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[10].count + "</b>");
  createP("The name: <b>" + entities[11].text + "</b>");
  createP("The type: <b>" + entities[11].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[11].count + "</b>");
  
  createP("The name: <b>" + entities[12].text + "</b>");
  createP("The type: <b>" + entities[12].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[12].count + "</b>");
  createP("The name: <b>" + entities[13].text + "</b>");
  createP("The type: <b>" + entities[13].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[13].count + "</b>");
  createP("The name: <b>" + entities[14].text + "</b>");
  createP("The type: <b>" + entities[14].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[14].count + "</b>");
  
  createP("The name: <b>" + entities[15].text + "</b>");
  createP("The type: <b>" + entities[15].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[15].count + "</b>");
  createP("The name: <b>" + entities[16].text + "</b>");
  createP("The type: <b>" + entities[16].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[16].count + "</b>");
  
  createP("The name: <b>" + entities[17].text + "</b>");
  createP("The type: <b>" + entities[17].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[17].count + "</b>");
  
  createP("The name: <b>" + entities[18].text + "</b>");
  createP("The type: <b>" + entities[18].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[18].count + "</b>");
  
  createP("The name: <b>" + entities[19].text + "</b>");
  createP("The type: <b>" + entities[19].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[19].count + "</b>");
  
  createP("The name: <b>" + entities[20].text + "</b>");
  createP("The type: <b>" + entities[20].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[20].count + "</b>");
  
  createP("The name: <b>" + entities[21].text + "</b>");
  createP("The type: <b>" + entities[21].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[21].count + "</b>");
  createP("The name: <b>" + entities[22].text + "</b>");
  createP("The type: <b>" + entities[22].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[22].count + "</b>");
  
  createP("The name: <b>" + entities[23].text + "</b>");
  createP("The type: <b>" + entities[23].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[23].count + "</b>");
  
  createP("The name: <b>" + entities[24].text + "</b>");
  createP("The type: <b>" + entities[24].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[24].count + "</b>");
  
  createP("The name: <b>" + entities[25].text + "</b>");
  createP("The type: <b>" + entities[25].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[25].count + "</b>");
  
  createP("The name: <b>" + entities[26].text + "</b>");
  createP("The type: <b>" + entities[26].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[26].count + "</b>");
  createP("The name: <b>" + entities[27].text + "</b>");
  createP("The type: <b>" + entities[27].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[27].count + "</b>");
  createP("The name: <b>" + entities[28].text + "</b>");
  createP("The type: <b>" + entities[28].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[28].count + "</b>");
  
  createP("The name: <b>" + entities[29].text + "</b>");
  createP("The type: <b>" + entities[29].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[29].count + "</b>");
  createP("The name: <b>" + entities[30].text + "</b>");
  createP("The type: <b>" + entities[30].type + "</b>");

  createP("The number of times mentionned : <b>" + entities[30].count + "</b>");
  
    // ==== keywords ANALYSIS ====

  var keywords = response.result.keywords;
  print(entities);
  createElement("h2", "Keywords Analysis");
  
  createP("The keywords 1 : <b>" + keywords[0].text + "</b>");
  createP("The relevance: <b>" + keywords[0].relevance + "</b>");
  
   createP("The keywords 2: <b>" + keywords[1].text + "</b>");
  createP("The relevance: <b>" + keywords[1].relevance + "</b>");
   createP("The keywords 3: <b>" + keywords[2].text + "</b>");
  createP("The relevance: <b>" + keywords[2].relevance + "</b>");
   createP("The keywords 4: <b>" + keywords[3].text + "</b>");
  createP("The relevance: <b>" + keywords[3].relevance + "</b>");
   createP("The keywords 5: <b>" + keywords[4].text + "</b>");
  createP("The relevance: <b>" + keywords[4].relevance + "</b>");
   createP("The keywords 6: <b>" + keywords[5].text + "</b>");
  createP("The relevance: <b>" + keywords[5].relevance + "</b>");
   createP("The keywords 7: <b>" + keywords[6].text + "</b>");
  createP("The relevance: <b>" + keywords[6].relevance + "</b>");
   createP("The keywords 8: <b>" + keywords[7].text + "</b>");
  createP("The relevance: <b>" + keywords[7].relevance + "</b>");
   createP("The keywords 9: <b>" + keywords[8].text + "</b>");
  createP("The relevance: <b>" + keywords[8].relevance + "</b>");
   createP("The keywords 10: <b>" + keywords[9].text + "</b>");
  createP("The relevance: <b>" + keywords[9].relevance + "</b>");
  
  
  




 
   
  
  
  
  
  
  }
}